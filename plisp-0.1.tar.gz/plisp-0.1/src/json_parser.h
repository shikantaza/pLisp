/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_JSON_SRC_JSON_PARSER_H_INCLUDED
# define YY_JSON_SRC_JSON_PARSER_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int jsondebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    T_INTEGER = 258,
    T_FLOAT = 259,
    T_STRING_LITERAL = 260,
    T_LEFT_CURLY_BRACE = 261,
    T_RIGHT_CURLY_BRACE = 262,
    T_LEFT_SQUARE_BRACE = 263,
    T_RIGHT_SQUARE_BRACE = 264,
    T_COMMA = 265,
    T_COLON = 266,
    END_OF_FILE = 267
  };
#endif
/* Tokens.  */
#define T_INTEGER 258
#define T_FLOAT 259
#define T_STRING_LITERAL 260
#define T_LEFT_CURLY_BRACE 261
#define T_RIGHT_CURLY_BRACE 262
#define T_LEFT_SQUARE_BRACE 263
#define T_RIGHT_SQUARE_BRACE 264
#define T_COMMA 265
#define T_COLON 266
#define END_OF_FILE 267

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 35 "src/json_parser.y" /* yacc.c:1915  */

  char                    *string_value;
  int                     integer_value;
  struct JSONObject       *object_value;
  double                  float_value;
  struct name_value_pairs *pairs;
  struct JSONObject       *array;
  struct JSONArray        *values;
  struct name_value_pair  *pair;

#line 89 "src/json_parser.h" /* yacc.c:1915  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE jsonlval;

int jsonparse (void);

#endif /* !YY_JSON_SRC_JSON_PARSER_H_INCLUDED  */
