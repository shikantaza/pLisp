#!/bin/sh
plisp -e '(progn (load-file "..\tests\unit_tests_windows.lisp") (load-file "..\tests\run_test_cases_windows.lisp"))'
